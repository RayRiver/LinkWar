#ifndef __ASTAR_H_INCLUDED__
#define __ASTAR_H_INCLUDED__

#include "DS_Vector.h"

struct ASPoint
{
	ASPoint(int _x=-1, int _y=-1) { x=_x; y=_y; }
	int x, y;
};

class AStar
{
public:
	AStar();
	virtual ~AStar();

public:
	bool LoadMap(unsigned char *map, unsigned int w, unsigned int h);
	const unsigned char *GetMap();
	unsigned int GetMapW();
	unsigned int GetMapH();

	void SetOrigin(ASPoint p);
	void GetOrigin(ASPoint &p);
	void SetDestination(ASPoint p);
	void GetDestination(ASPoint &p);

	bool FindPath(DS_Vector<ASPoint> &path);

private:
	bool CheckChild(int x, int y, void *parent);
	void ClearNodes();

private:
	struct PIMPL;
	PIMPL *m;

};

#endif // __ASTAR_H_INCLUDED__
