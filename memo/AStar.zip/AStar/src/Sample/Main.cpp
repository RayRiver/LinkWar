#include <stdio.h>

#include "AStarRDS.h"

#define MAP_W 24
#define MAP_H 18
unsigned char g_map[MAP_H][MAP_W] = {
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,1,1,0,1,0,1,0,0,1,1,1,1,1,0,1,1,0,1,0,0,1,0},
	{0,1,0,1,0,1,0,1,1,1,1,0,0,1,1,1,0,1,1,1,1,1,1,0},
	{0,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,0,1,0,1,0,1,0,0},
	{0,1,0,1,0,1,0,0,1,0,1,1,1,1,0,1,1,1,0,1,0,1,1,0},
	{0,1,1,0,1,1,0,0,1,1,1,1,0,1,1,0,1,1,0,1,1,0,1,0},
	{0,1,1,0,1,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,0,0,1,0},
	{0,1,1,0,1,1,0,1,1,0,1,0,1,1,0,0,1,1,0,1,1,1,1,0},
	{0,1,0,1,0,1,0,0,0,0,1,1,0,1,0,1,0,1,0,1,0,1,1,0},
	{0,1,1,0,1,1,0,1,1,0,1,0,1,1,0,1,1,0,1,1,0,0,1,0},
	{0,1,1,1,1,1,0,1,1,1,1,0,1,0,1,0,1,1,1,1,1,0,1,0},
	{0,1,1,0,1,1,0,0,0,1,0,1,1,1,1,0,1,1,0,1,1,0,1,0},
	{0,1,1,0,1,1,0,0,1,1,0,1,0,1,1,0,1,1,0,1,1,0,1,0},
	{0,1,1,0,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,1,0,1,0},
	{0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,0,1,0,1,1,0},
	{0,1,1,0,1,1,0,1,1,0,1,0,1,1,0,1,0,1,0,1,1,0,1,0},
	{0,1,1,1,1,0,1,1,1,1,0,1,0,1,1,0,1,1,0,1,1,0,1,0},
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
};

//#include <iostream>
//#include <vector>
// #include <queue>
//using namespace std;
void print(int elem)
{
//	cout << elem << ' ';
}

void test()
{
// 	vector<int> coll;
// 	//int n;
// 
// 	//make_heap(coll.begin(), coll.end());
// 
// 	coll.push_back(5);
// 	push_heap(coll.begin(), coll.end());
// 	coll.push_back(44);
// 	push_heap(coll.begin(), coll.end());
// 	coll.push_back(9);
// 	push_heap(coll.begin(), coll.end());
// 	coll.push_back(99);
// 	push_heap(coll.begin(), coll.end());
// 	coll.push_back(14);
// 	push_heap(coll.begin(), coll.end());
// 	for_each(coll.begin(), coll.end(), print);
// 	cout << endl;
// 
// 	// 	make_heap(coll.begin(), coll.end());
// 	// 	cout << "After make_heap()" << endl;
// 	// 	for_each(coll.begin(), coll.end(), print);
// 	// 	cout << endl;
// 
// 
// 	coll.push_back(100);
// 	push_heap(coll.begin(), coll.end());
// 
// 	cout << "After push_heap()" << endl;
// 	for_each(coll.begin(), coll.end(), print);
// 	cout << endl;
// 
// 	pop_heap(coll.begin(), coll.end());
// 	cout << "After pop_heap()" << endl;
// 	for_each(coll.begin(), coll.end(), print);
// 	cout << endl;
// 
// 	cout << "coll.back() : " << coll.back() << endl;
// 	coll.pop_back();
// 	cout << "After pop_back()" << endl;
// 	for_each(coll.begin(), coll.end(), print);
// 	cout << endl;
// 
// 	sort_heap(coll.begin(), coll.end());
// 	cout << "After sort_heap()" << endl;
// 	for_each(coll.begin(), coll.end(), print);
// 	cout << endl;
// 
// 	getchar();
}

void PrintMap(AStar &as, DS_Vector<ASPoint> &path)
{
	for ( unsigned int h=0; h<as.GetMapH(); ++h ) 
	{
		for ( unsigned int w=0; w<as.GetMapW(); ++w ) 
		{
			ASPoint org, des;
			as.GetOrigin(org);
			as.GetDestination(des);
			const unsigned char *map = as.GetMap();

			if ( w==org.x && h==org.y ) { printf("��");	 continue; }	// ���
			if ( w==des.x && h==des.y ) { printf("��");	 continue; }	// �յ�
			switch ( map[h*as.GetMapW()+w] ) 
			{
			case 0:
				{
					printf("��");	// �ϰ���
					break;
				}
			case 1:
				{
					bool bPath = false;
					for ( size_t i=0; i<path.Size(); ++i ) 
					{
						if ( path[i].x==w && path[i].y==h ) 
						{
							if ( i+1 >= path.Size() ) break;
							if ( path[i+1].x>path[i].x && path[i+1].y==path[i].y ) {
								printf("��");
							} else if ( path[i+1].x>path[i].x && path[i+1].y>path[i].y ) {
								printf("�K");
							} else if ( path[i+1].x>path[i].x && path[i+1].y<path[i].y ) {
								printf("�J");
							} else if ( path[i+1].x<path[i].x && path[i+1].y==path[i].y ) {
								printf("��");
							} else if ( path[i+1].x<path[i].x && path[i+1].y>path[i].y ) {
								printf("�L");
							} else if ( path[i+1].x<path[i].x && path[i+1].y<path[i].y ) {
								printf("�I");
							} else if ( path[i+1].x==path[i].x && path[i+1].y<path[i].y ) {
								printf("��");
							} else if ( path[i+1].x==path[i].x && path[i+1].y>path[i].y ) {
								printf("��");
							}

							bPath = true;
							break;
						}
					}
					if ( !bPath ) printf("  ");	// ����
					break;
				}
			}

		}
		printf("\n");
	}
}

int main(int argc, char* argv[])
{
	// 	test();
	//  return 0;


	AStar as;
	if ( !as.LoadMap(&g_map[0][0], MAP_W, MAP_H) ) {
		printf("LoadMap error\n");
		return 1;
	}
	as.SetOrigin( ASPoint(3,4) );
	as.SetDestination( ASPoint(10,1) );
	DS_Vector<ASPoint> path;

	PrintMap(as, path);
	if ( as.FindPath(path) ) {
		printf("find way\n");
		PrintMap(as, path);
	} else {
		printf("sry, no way out..");
	}

	getchar();
	return 0;
}

