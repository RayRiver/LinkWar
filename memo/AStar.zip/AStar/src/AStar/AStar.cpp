#include "AStar.h"

#include <stdio.h>
#include <stdlib.h>
#include <crtdbg.h>
#include <math.h>

#include <algorithm>
#include <vector>
using namespace std;

#define CORNER_COST		1.414f
#define SIDE_COST		1.0f

// G: ����ʼ״̬����ǰ״̬��ʵ�ʴ��ۣ�׼ȷ��
// H: �ӵ�ǰ״̬��Ŀ��״̬�Ĺ��ƴ��ۣ������ٷ���
// F: ����ʼ״̬��Ŀ��״̬��Ԥ�ƴ��ۣ�G+H��
struct ASNode
{
	ASNode() { point.x=point.y=-1; F=G=H=0.0f; parent=NULL; }
	ASPoint point;
	double F, G, H;
	ASNode *parent;
};

// ����ѱȽ��㷨����Fֵ�Ƚϣ�С���ѣ�
template <typename T>
class MinBinaryHeapCompare
{
public:
	bool operator() ( T a, T b ) const
	{
		return a->F>b->F;
	}
};

struct AStar::PIMPL
{
	unsigned char *map;
	unsigned int mapW, mapH;
	int orgX, orgY, desX, desY;
	vector<ASNode *> OpenNodes;
	vector<ASNode *> ClosedNodes;
};

AStar::AStar()
{
	m = new PIMPL;
	m->map = NULL;
	m->mapW = m->mapH = 0;
	m->orgX = m->orgY = m->desX = m->desY = -1;
}

AStar::~AStar()
{
	ClearNodes();
	if ( m->map ) {
		delete m->map;
		m->map = NULL;
	}
	delete m;
}

bool AStar::LoadMap( unsigned char *map, unsigned int w, unsigned int h )
{
	if ( map==NULL || w==0 || h==0 ) { _ASSERT(false); return false; }

	unsigned char *tempmap = new unsigned char[w*h];
	if ( tempmap==NULL ) return false;

	if ( m->map ) {
		delete m->map;
		m->map = NULL;
	}
	m->map = tempmap;
	memcpy(m->map, map, sizeof(unsigned char)*w*h);

	m->mapW = w;
	m->mapH = h;

	return true;
}

const unsigned char * AStar::GetMap()
{
	return m->map;
}

unsigned int AStar::GetMapW()
{
	return m->mapW;
}

unsigned int AStar::GetMapH()
{
	return m->mapH;
}

void AStar::SetOrigin( ASPoint p )
{
	m->orgX = p.x;
	m->orgY = p.y;
}

void AStar::GetOrigin( ASPoint &p )
{
	p.x = m->orgX;
	p.y = m->orgY;
}

void AStar::SetDestination( ASPoint p )
{
	m->desX = p.x;
	m->desY = p.y;
}

void AStar::GetDestination( ASPoint &p )
{
	p.x = m->desX;
	p.y = m->desY;
}

bool AStar::FindPath(vector<ASPoint> &path)
{
	if ( m->map==NULL || m->mapW==0 || m->mapH==0 ) { _ASSERT(false); return false; }
	if ( m->orgX<0 || m->orgY<0 || m->desX<0 || m->desY<0 ) { _ASSERT(false); return false; }

	// ��ʼ�ڵ�ѹ��OpenNodes
	ASNode *startNode = new ASNode;
	if ( startNode == NULL ) { return false; }
	startNode->point.x = m->orgX;
	startNode->point.y = m->orgY;
	m->OpenNodes.push_back(startNode);
	make_heap(m->OpenNodes.begin(), m->OpenNodes.end(), MinBinaryHeapCompare<ASNode *>());

	while ( !m->OpenNodes.empty() ) 
	{
		// �ڿ����б���Ѱ��Fֵ��С�Ľڵ�
		pop_heap(m->OpenNodes.begin(), m->OpenNodes.end(), MinBinaryHeapCompare<ASNode *>());
		ASNode *node = m->OpenNodes.back();
		_ASSERT(node);

		// ���ýڵ�ӿ����б����Ƴ����������б�
		//m->OpenNodes.erase(itCurrent);
		m->OpenNodes.pop_back();
		m->ClosedNodes.push_back(node);

		// �ҵ�·��������
		if ( node->point.x==m->desX && node->point.y==m->desY )
		{
			ASNode *tempnode = node;
			do {
				path.insert(path.begin(), tempnode->point);
				tempnode = tempnode->parent;
			} while ( tempnode->parent );
			path.insert(path.begin(), startNode->point);
			ClearNodes();
			return true;
		}

		// �����ٽ�8�������
		// 1  2  3
		// 4     6
		// 7  8  9
		CheckChild(node->point.x+1, node->point.y, node);		// 6
		CheckChild(node->point.x+1, node->point.y-1, node);		// 3
		CheckChild(node->point.x+1, node->point.y+1, node);		// 9
		CheckChild(node->point.x, node->point.y-1,	node);		// 2
		CheckChild(node->point.x, node->point.y+1, node);		// 8
		CheckChild(node->point.x-1, node->point.y, node);		// 1
		CheckChild(node->point.x-1, node->point.y-1, node);		// 4
		CheckChild(node->point.x-1, node->point.y+1, node);		// 7

	}

	// δ�ҵ�
	ClearNodes();
	return false;
}

// ----------------------------------- private functions bellow -----------------------------------

// �����ٷ�����Hֵ
static double AStarGetH(int x1, int y1, int x2, int y2)
{
	return (fabs((double)(x2-x1))+fabs((double)(y2-y1))) * SIDE_COST;
}

bool AStar::CheckChild( int x, int y, void *parent )
{
	if ( parent==NULL ) { _ASSERT(false); return false; }
	ASNode *parentNode = (ASNode *)parent;

	// �ڵ㲻�ɴ�
	if ( x<0 || (unsigned int)x>=m->mapW || y<0 || (unsigned int)y>=m->mapH || m->map[y*m->mapW+x]==0 ) return true;

	// �������ӶԽ�ǽ�д���
	if ( parentNode->point.x!=x && parentNode->point.y!=y ) {
		if ( m->map[parentNode->point.y*m->mapW+x]==0 && m->map[y*m->mapW+parentNode->point.x]==0 ) return true;	
	}

	double G = 0.0f;
	if ( parentNode->point.x!=x && parentNode->point.y!=y ) G = parentNode->G + CORNER_COST;
	else G = parentNode->G + SIDE_COST;

	// ����Ƿ���ڷ���б��У��ڷ���б�����ʲô������
	ASNode *node = NULL;
	for ( vector<ASNode *>::iterator it=m->ClosedNodes.begin(); it!=m->ClosedNodes.end(); ++it ) {
		if ( (*it)->point.x==x && (*it)->point.y==y ) node = *it;
	}
	if ( node ) {
		return true;
	}

	// ����Ƿ���ڿ����б���
	node = NULL;
	for ( vector<ASNode *>::iterator it=m->OpenNodes.begin(); it!=m->OpenNodes.end(); ++it ) {
		if ( (*it)->point.x==x && (*it)->point.y==y ) node = *it;
	}
	if ( node ) {
		// �Ѵ����ڿ����б��У��ж���parentNode����ýڵ��Gֵ�Ƿ�С��ԭ�������Gֵ
		// ���С�ڣ������øýڵ���¸��׽ڵ�
		// �����û����һ�Σ�Ҳ��Ѱ�ҵ�·�������ǲ����������̵ĵ�����
		if ( G < node->G ) {
			node->F -= (node->G-G);
			node->G = G;
			node->parent = parentNode;
			make_heap(m->OpenNodes.begin(), m->OpenNodes.end(), MinBinaryHeapCompare<ASNode *>());
		}
	} else {
		// �����ڿ����б��У������
		node = new ASNode;
		if ( node == NULL ) { _ASSERT(false); return false; }
		node->point.x = x;
		node->point.y = y;
		node->G = G;
		node->H = AStarGetH(node->point.x, node->point.y, m->desX, m->desY);
		node->F = node->G + node->H;
		node->parent = parentNode;
		m->OpenNodes.push_back(node);
		push_heap(m->OpenNodes.begin(), m->OpenNodes.end(), MinBinaryHeapCompare<ASNode *>());
	}

	return true;
}

void AStar::ClearNodes()
{
	for ( vector<ASNode *>::iterator it=m->OpenNodes.begin(); it!=m->OpenNodes.end(); ++it ) {
		if ( *it ) delete *it;
	}
	m->OpenNodes.clear();
	for ( vector<ASNode *>::iterator it=m->ClosedNodes.begin(); it!=m->ClosedNodes.end(); ++it ) {
		if ( *it ) delete *it;
	}
	m->ClosedNodes.clear();
}

