#include "EXRender.h"

#include <math.h>
#include <hge.h>

void EXRenderCircle(HGE *hge, float x, float y, float radius, unsigned long argb, unsigned long sides/*=32*/)
{
// 	// �ٽ�ֵx����������С������ٽ�ֵ
// 	float X = M_PI / asin( 0.5f/radius );
// 	if ( sides > (unsigned long)X ) sides = (unsigned long)X;

	// ����3��
	if ( sides < 3 ) sides = 3;

	// ��λ�Ƕ�
	float fUnitAngle = 2*M_PI/(float)sides;

	float fLastAngle = 0.0f;
	float fAngle = 0.0f;
	for ( unsigned long side=0; side<sides; ++side ) {
		fAngle = fLastAngle + fUnitAngle;
		hge->Gfx_RenderLine(x+radius*sin(fLastAngle), y+radius*cos(fLastAngle), x+radius*sin(fAngle), y+radius*cos(fAngle), argb, 0);
		fLastAngle = fAngle;
	}
}