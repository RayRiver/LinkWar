#ifndef __GLOBAL_H_INCLUDED__
#define __GLOBAL_H_INCLUDED__

#include <hge.h>
#include <hgefont.h>
#include <hgeGui.h>
#include <hgeSprite.h>

#define SCREEN_X			640
#define SCREEN_Y			480
	
#define MAP_W				32
#define MAP_H				24
#define BLOCK_SIDE			(SCREEN_X/MAP_W)


inline unsigned int Coordinate2MapIndex(float x) { 
	return (unsigned int)(((int)x)/BLOCK_SIDE); 
}
inline float MapIndex2Coordinate(unsigned int x) { 
	return (float)((x+0.5)*BLOCK_SIDE); 
} 

extern HGE *g_hge;
extern hgeFont *g_font;

extern HTEXTURE g_TexCursor;
extern hgeGUI *g_GUI;
extern hgeSprite *g_Cursor;

class AStar;
extern AStar g_AStar;

#endif // __GLOBAL_H_INCLUDED__
