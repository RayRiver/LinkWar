#include <stdio.h>
#include <stdlib.h>
#include <crtdbg.h>
#include <time.h>
#include <math.h>

#include <vector>
using namespace std;

#include "AStar.h"
#include "Global.h"
#include "EXRender.h"

HTEXTURE g_tex;

// ��ǰ�ҵ���·��
vector<ASPoint> path;

// ȫ�ֵ�ͼ
unsigned char map[MAP_W*MAP_H];

// �Ƿ���ʾ����
bool bShowGrid = true;

bool Update()
{
	float dt = g_hge->Timer_GetDelta();

	// �����޸ĵ�ͼ�¼�
	bool bDrawing = false;
	bool bErasing = false;
	if ( g_hge->Input_GetKeyState(HGEK_LBUTTON) ) { bDrawing = true; }
	if ( g_hge->Input_GetKeyState(HGEK_RBUTTON) ) { bErasing = true; }
	if ( bDrawing || bErasing ) {
		float fMouseX, fMouseY;
		g_hge->Input_GetMousePos(&fMouseX, &fMouseY);
		unsigned int w = Coordinate2MapIndex(fMouseX);
		unsigned int h = Coordinate2MapIndex(fMouseY);

		bool bMapChanged = false;
		if ( bDrawing ) {
			if ( map[h*MAP_W+w] == 1 ) {
				map[h*MAP_W+w] = 0;
				bMapChanged = true;
			}
		} else if ( bErasing ) {
			if ( map[h*MAP_W+w] == 0 ) {
				map[h*MAP_W+w] = 1;
				bMapChanged = true;
			}
		}
		if ( bMapChanged ) {	// �����ͼ�ı䣬����Ѱ��·��
			g_AStar.LoadMap(map, MAP_W, MAP_H);
			path.clear();
			g_AStar.FindPath(path);
			bMapChanged = false;
		}
	}

	// ������ݼ�
	hgeInputEvent e;
	bool bRet = g_hge->Input_GetEvent(&e);
	if ( bRet )
	{
		if ( e.type==INPUT_KEYDOWN && e.key==HGEK_F1 ) 
		{
			bShowGrid = !bShowGrid;
		}
	}

	g_GUI->Update(dt);

	return false;
}

bool Render()
{
	g_hge->Gfx_BeginScene();
	g_hge->Gfx_Clear(0);

	// ���Ʒָ��ͼ
	if ( bShowGrid ) {
		for ( unsigned int h=0; h<MAP_H; ++h ) {
			g_hge->Gfx_RenderLine(0, (float)(h*BLOCK_SIDE), SCREEN_X, (float)(h*BLOCK_SIDE), 0xff666666, 0);
		}
		for ( unsigned int w=0; w<MAP_W; ++w ) {
			g_hge->Gfx_RenderLine((float)(w*BLOCK_SIDE), 0, (float)(w*BLOCK_SIDE), SCREEN_Y, 0xff666666, 0);
		}
	}

	// �������
	ASPoint org;
	g_AStar.GetOrigin(org);
	if ( org.x>=0 && org.y>=0 ) {	
		EXRenderCircle(g_hge, MapIndex2Coordinate(org.x), MapIndex2Coordinate(org.y), BLOCK_SIDE/4, 0xffff0000);
	}

	// �����յ�
	ASPoint dst;
	g_AStar.GetDestination(dst);
	if ( dst.x>=0 && dst.y>=0 ) {
		EXRenderCircle(g_hge, MapIndex2Coordinate(dst.x), MapIndex2Coordinate(dst.y), BLOCK_SIDE/4, 0xff00ff00);
	}

	// �����ϰ���
	for ( unsigned int w=0; w<MAP_W; ++w ) 
	{
		for ( unsigned int h=0; h<MAP_H; ++h ) 
		{
			if ( map[h*MAP_W+w] == 1 ) continue;
			float x = MapIndex2Coordinate(w);
			float y = MapIndex2Coordinate(h);
			float sprite_radius = BLOCK_SIDE/2;

			hgeQuad quad;
			quad.v[0].x=x-sprite_radius; quad.v[0].y=y-sprite_radius;
			quad.v[1].x=x+sprite_radius; quad.v[1].y=y-sprite_radius;
			quad.v[2].x=x+sprite_radius; quad.v[2].y=y+sprite_radius;
			quad.v[3].x=x-sprite_radius; quad.v[3].y=y+sprite_radius;

			quad.v[0].tx=0.0f; quad.v[0].ty=0.0f;
			quad.v[1].tx=1.0f; quad.v[1].ty=0.0f;
			quad.v[2].tx=1.0f; quad.v[2].ty=1.0f;
			quad.v[3].tx=0.0f; quad.v[3].ty=1.0f;

			quad.blend = BLEND_ALPHAADD | BLEND_COLORMUL | BLEND_ZWRITE;
			quad.tex = g_tex;

			for ( int i=0; i<4; ++i ) {
				quad.v[i].z = 0.5f;
				quad.v[i].col = 0xffffffff;
			}
			g_hge->Gfx_RenderQuad(&quad);
		}
	}

	// ���ư�����Ϣ
	char szBuffer[128];
	_snprintf_s(szBuffer, sizeof(szBuffer), sizeof(szBuffer)-1, "Press F1 to show/hide grid");
	g_font->Render(5, SCREEN_Y-20, HGETEXT_LEFT, szBuffer);

	// ���Ƶ�ǰ·���Լ�������Ϣ
	double dist = 0.0f;
	if ( path.size() == 0 ) {
		g_font->Render(SCREEN_X-5, SCREEN_Y-20, HGETEXT_RIGHT, "NO WAY OUT");
	} else {
		for ( size_t i=0; i<path.size()-1; ++i ) {
			float x1 = MapIndex2Coordinate(path[i].x);
			float y1 = MapIndex2Coordinate(path[i].y);
			float x2 = MapIndex2Coordinate(path[i+1].x);
			float y2 = MapIndex2Coordinate(path[i+1].y);
			dist += sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) );
			g_hge->Gfx_RenderLine(x1, y1, x2, y2, 0xff00aa00, 0);
		}
		char szBuffer[128];
		_snprintf_s(szBuffer, sizeof(szBuffer), sizeof(szBuffer)-1, "dist: %.f",  dist);
		g_font->Render(SCREEN_X-5, SCREEN_Y-20, HGETEXT_RIGHT, szBuffer);
	}

	

	

	g_GUI->Render();

	g_hge->Gfx_EndScene();
	return false;

	return false;
}

bool gameapp()
{
	srand((unsigned int)time(NULL));

	g_hge = hgeCreate(HGE_VERSION);
	if ( g_hge == NULL ) {
		return false;
	}

	g_hge->System_SetState(HGE_LOGFILE, "trace.log");
	g_hge->System_SetState(HGE_FRAMEFUNC, Update);
	g_hge->System_SetState(HGE_RENDERFUNC, Render);
	g_hge->System_SetState(HGE_TITLE, "AStar Sample 2");

	g_hge->System_SetState(HGE_WINDOWED, true);
	g_hge->System_SetState(HGE_SCREENWIDTH,  SCREEN_X);
	g_hge->System_SetState(HGE_SCREENHEIGHT, SCREEN_Y);
	g_hge->System_SetState(HGE_SCREENBPP, 32);

	g_hge->System_SetState(HGE_USESOUND, true);

	g_hge->System_SetState(HGE_SHOWSPLASH, false);

	if ( !g_hge->System_Initiate() ) {
		_ASSERT(false);
		return false;
	}

	g_GUI = new hgeGUI();
	g_TexCursor = g_hge->Texture_Load("./cursor.png");
	if ( g_TexCursor ) {
		g_Cursor = new hgeSprite(g_TexCursor, 0, 0, 32, 32);
		g_GUI->SetCursor(g_Cursor);
	}

	g_font = new hgeFont("./main_font.fnt");
	g_tex = g_hge->Texture_Load("tex.png");

	unsigned int i = 0;
	for ( unsigned int w=0; w<MAP_W; ++w ) {
		for ( unsigned int h=0; h<MAP_H; ++h ) {
			map[i++] = 1;
		}
	}
	g_AStar.LoadMap(map, MAP_W, MAP_H);
	g_AStar.SetOrigin( ASPoint(5,3) );
	g_AStar.SetDestination( ASPoint(MAP_W-1,MAP_H-1) );
	if ( !g_AStar.FindPath(path) ) {
		_ASSERT(false);
		return false;
	}
	


	g_hge->System_Start();



	g_hge->System_Shutdown();
	g_hge->Release();

	return true;
}

int main(int argc, char* argv[])
{
	gameapp();

	return 0;
}

