#ifndef __EXRENDER_H_INCLUDED__
#define __EXRENDER_H_INCLUDED__

class HGE;

extern void EXRenderCircle(HGE *hge, float x, float y, float radius, unsigned long argb, unsigned long sides=32);

#endif // __EXRENDER_H_INCLUDED__
