#include "Global.h"

#include "AStar.h"

HGE *g_hge = NULL;
hgeFont *g_font = NULL;

HTEXTURE g_TexCursor = 0;
hgeGUI *g_GUI = NULL;
hgeSprite *g_Cursor = NULL;

AStar g_AStar;
